package com.econova.calculadora;

public class DadosEntrada {
    private double gasolina;
    private double alcool;
    private double diesel;
    private double eletrico;
    private double consumoEletrico;
    private double consumoGas;
    private double kgResiduos;
    private double kgPapel;

    // Getters and Setters

    public double getGasolina() {
        return gasolina;
    }

    public void setGasolina(double gasolina) {
        this.gasolina = gasolina;
    }

    public double getAlcool() {
        return alcool;
    }

    public void setAlcool(double alcool) {
        this.alcool = alcool;
    }

    public double getDiesel() {
        return diesel;
    }

    public void setDiesel(double diesel) {
        this.diesel = diesel;
    }

    public double getEletrico() {
        return eletrico;
    }

    public void setEletrico(double eletrico) {
        this.eletrico = eletrico;
    }

    public double getConsumoEletrico() {
        return consumoEletrico;
    }

    public void setConsumoEletrico(double consumoEletrico) {
        this.consumoEletrico = consumoEletrico;
    }

    public double getConsumoGas() {
        return consumoGas;
    }

    public void setConsumoGas(double consumoGas) {
        this.consumoGas = consumoGas;
    }

    public double getKgResiduos() {
        return kgResiduos;
    }

    public void setKgResiduos(double kgResiduos) {
        this.kgResiduos = kgResiduos;
    }

    public double getKgPapel() {
        return kgPapel;
    }

    public void setKgPapel(double kgPapel) {
        this.kgPapel = kgPapel;
    }
}

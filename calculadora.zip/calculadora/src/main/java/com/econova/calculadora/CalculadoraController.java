package com.econova.calculadora;

import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/api/calculadora")
public class CalculadoraController {

    @PostMapping("/calcular")
    public String calcularEmissao(@RequestBody DadosEntrada dados) {
        // Processa os dados enviados pelo frontend
        double gasolina = dados.getGasolina();
        double alcool = dados.getAlcool();
        double diesel = dados.getDiesel();
        double eletrico = dados.getEletrico();
        double consumoEletrico = dados.getConsumoEletrico();
        double consumoGas = dados.getConsumoGas();
        double kgResiduos = dados.getKgResiduos();
        double kgPapel = dados.getKgPapel();

        // Cálculos
        double emissaoVGasolina = gasolina * 2.31;
        double emissaoVAlcool = alcool * 1.86;
        double emissaoVDiesel = diesel * 2.68;
        double emissaoVEletrico = eletrico * 0.5;
        double emissaoVTotal = emissaoVGasolina + emissaoVAlcool + emissaoVDiesel + emissaoVEletrico;

        double eletricidade = consumoEletrico * 0.5;
        double gas = consumoGas * 2.0;
        double residuo = kgResiduos * 1.2;
        double papel = kgPapel * 1.5;

        double emissaoTotal = emissaoVTotal + eletricidade + gas + residuo + papel;

        // Obtém o mês atual e traduz para português
        LocalDate dataAtual = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM").withLocale(new java.util.Locale("pt", "BR"));
        String mesAtual = dataAtual.format(formatter);

        return String.format("A emissão de carbono total no mês de %s é: %.2f kg de CO2", mesAtual, emissaoTotal);
    }
}

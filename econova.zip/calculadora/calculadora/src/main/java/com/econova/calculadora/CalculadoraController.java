package com.econova.calculadora;

import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/calculadora")
public class CalculadoraController {
    @PostMapping("/calcular")
    public double calcularEmissoes(@RequestBody DadosEntrada dados) {
        // Calcular emissões
        double emissaoVGasolina = dados.getGasolina() * 2.31;
        double emissaoVAlcool = dados.getAlcool() * 1.86;
        double emissaoVDiesel = dados.getDiesel() * 2.68;
        double emissaoVEletrico = dados.getEletrico() * 0.5;

        double emissaoVTotal = emissaoVGasolina + emissaoVAlcool + emissaoVDiesel + emissaoVEletrico;
        double eletricidade = dados.getConsumoEletrico() * 0.5;
        double gas = dados.getConsumoGas() * 2.0;
        double residuo = dados.getKgResiduos() * 1.2;
        double papel = dados.getKgPapel() * 1.5;

        return emissaoVTotal + eletricidade + gas + residuo + papel;
    }
}

class DadosEntrada {
    private double gasolina;
    private double alcool;
    private double diesel;
    private double eletrico;
    private double consumoEletrico;
    private double consumoGas;
    private double kgResiduos;
    private double kgPapel;

    public double getGasolina() {
        return gasolina;
    }
    public void setGasolina(double gasolina) {
        this.gasolina = gasolina;
    }
    public double getAlcool() {
        return alcool;
    }
    public void setAlcool(double alcool) {
        this.alcool = alcool;
    }
    public double getDiesel() {
        return diesel;
    }
    public void setDiesel(double diesel) {
        this.diesel = diesel;
    }
    public double getEletrico() {
        return eletrico;
    }
    public void setEletrico(double eletrico) {
        this.eletrico = eletrico;
    }
    public double getConsumoEletrico() {
        return consumoEletrico;
    }
    public void setConsumoEletrico(double consumoEletrico) {
        this.consumoEletrico = consumoEletrico;
    }
    public double getConsumoGas() {
        return consumoGas;
    }
    public void setConsumoGas(double consumoGas) {
        this.consumoGas = consumoGas;
    }
    public double getKgResiduos() {
        return kgResiduos;
    }
    public void setKgResiduos(double kgResiduos) {
        this.kgResiduos = kgResiduos;
    }
    public double getKgPapel() {
        return kgPapel;
    }
    public void setKgPapel(double kgPapel) {
        this.kgPapel = kgPapel;
    }
}

